---
title: index
type: textbook
source_path: content/03-public/index.md
chapter: 3
---

# Public Economics

**Public economics** deals with the different methods government policy affect market equilibria, and studies these through the lens of economic efficiency and equity. This chapter begins with a graphical and mathematical overview of market equilibrium. It follows with a discussion of consumer and producer surplus - specifically how these concepts underscore the competing forces of supply and demand. Last, it covers the different ways in which governments intervene: taxes, subsidies and price controls. It discusses their effects on welfare and how intervention changes market participation
