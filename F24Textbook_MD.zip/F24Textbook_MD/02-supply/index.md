---
title: index
type: textbook
source_path: content/02-supply/index.md
chapter: 2
---

# Supply and Market Equilibrium

**Student Learning Outcomes:**
* Know how a supply curve is formed
* Understand when and how much a firm decided to produce
* Understand demand and price elasticities of goods
* Use SymPy to solve systems of supply and demand equations
* Calculate the price equilibrium

