---
title: index
type: textbook
source_path: content/09-macro/index.md
chapter: 9
---

# Macroeconomic Policy

## Student Learning Outcomes:
- Learn about the 4 main macro indicators and how they relate to one another
- Learn how to graphically represent these relationships and understand historical trends
- Learn about central banks and the tools they use for monetary and fiscal policy
- Improve macro literacy 
