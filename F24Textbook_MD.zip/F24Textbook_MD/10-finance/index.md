---
title: index
type: textbook
source_path: content/10-finance/index.md
chapter: 10
---

# Finance

This week, we will be covering some of the greatest hits of Financial Economics - most of which you can learn by taking Econ 136. We will begin our discussion with an important introduction to interest rates and the time value of money. After, we will pivot to stock options. These are ways investors can bet on stock value movements through purchasing or selling contracts that only have value at certain stock prices.
