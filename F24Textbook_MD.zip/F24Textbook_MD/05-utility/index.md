---
title: index
type: textbook
source_path: content/05-utility/index.md
chapter: 5
---

# Utility

**Student Learning Outcomes:**

* Understand the basic principles of utility 
* Become familiar with utility function such as the Cobb-Douglas utility function
* Translate utility functions with 2 inputs to indifference curves
* Understand budget constraints and how they affect utility maximization
